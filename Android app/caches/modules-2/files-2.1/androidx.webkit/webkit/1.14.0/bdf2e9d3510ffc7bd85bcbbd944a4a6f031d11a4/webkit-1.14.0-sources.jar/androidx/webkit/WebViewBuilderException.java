/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.webkit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

/**
 * Thrown by {@link WebViewBuilder#build} if there was an issue with validation, or constructing the
 * WebView.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class WebViewBuilderException extends Exception {

    WebViewBuilderException(@NonNull String error, @Nullable Throwable cause) {
        super(error, cause);
    }
}
